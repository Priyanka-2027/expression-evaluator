# How to Run the Project

## Prerequisites
- Node.js (v16 or higher recommended)
- npm (comes with Node.js)

## Installation

1. Navigate to the project directory:
   ```bash
   cd d:\Desktop\expression\project
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

## Available Scripts

- Start development server:
  ```bash
  npm run dev
  ```
  Open [http://localhost:5173](http://localhost:5173) to view it in your browser.

- Create production build:
  ```bash
  npm run build
  ```

- Preview production build locally:
  ```bash
  npm run preview
  ```

- Lint code:
  ```bash
  npm run lint
  ```

- Type checking:
  ```bash
  npm run typecheck
  ```

## Development Server
- The development server runs on `http://localhost:5173`
- The page will automatically reload when you make changes
- You may see any lint errors in the console

## Note
- If you see any browserlist warnings, you can update it by running:
  ```bash
  npx update-browserslist-db@latest
  ```
- For security vulnerabilities, run:
  ```bash
  npm audit fix
  ```
