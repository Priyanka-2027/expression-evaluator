import { useState, useEffect } from 'react';
import { Moon, Sun, Copy, ChevronDown } from 'lucide-react';
import { convertExpression, validateExpression, VisualizationStep } from '../utils/expressionConverter';
import Visualization from './Visualization';

interface ConversionRules {
  title: string;
  rules: string[];
  example: { input: string; output: string };
}

const conversionRulesMap: Record<string, ConversionRules> = {
  'infix-to-postfix': {
    title: 'Infix to Postfix (Shunting Yard Algorithm)',
    rules: [
      'Operands: Output immediately',
      'Operators: Compare with stack top by precedence',
      'Higher precedence stays in stack, lower/equal pops to output',
      'Left parenthesis: Push to stack',
      'Right parenthesis: Pop until matching left parenthesis',
      'End: Pop all remaining operators to output'
    ],
    example: { input: 'A + B * C', output: 'A B C * +' }
  },
  'infix-to-prefix': {
    title: 'Infix to Prefix',
    rules: [
      'Reverse the infix expression',
      'Swap all opening "(" with closing ")" and vice versa',
      'Convert to postfix using Shunting Yard',
      'Reverse the result to get prefix'
    ],
    example: { input: 'A + B * C', output: '+ A * B C' }
  },
  'prefix-to-infix': {
    title: 'Prefix to Infix',
    rules: [
      'Process tokens from right to left',
      'Operands: Push to stack',
      'Operators: Pop two operands, combine as (op1 operator op2)',
      'Push result back to stack',
      'Final stack top is the infix expression'
    ],
    example: { input: '+ A * B C', output: '(A (B C *) +)' }
  },
  'postfix-to-infix': {
    title: 'Postfix to Infix',
    rules: [
      'Process tokens left to right',
      'Operands: Push to stack',
      'Operators: Pop two operands, combine as (op1 operator op2)',
      'Push result back to stack',
      'Final stack top is the infix expression'
    ],
    example: { input: 'A B C * +', output: '(A (B C *) +)' }
  },
  'prefix-to-postfix': {
    title: 'Prefix to Postfix',
    rules: [
      'Convert prefix to infix first',
      'Convert infix to postfix using Shunting Yard',
      'Result is the postfix expression'
    ],
    example: { input: '+ A * B C', output: 'A B C * +' }
  },
  'postfix-to-prefix': {
    title: 'Postfix to Prefix',
    rules: [
      'Convert postfix to infix first',
      'Convert infix to prefix using reverse method',
      'Result is the prefix expression'
    ],
    example: { input: 'A B C * +', output: '+ A * B C' }
  }
};

export default function ExpressionConverter() {
  const [expression, setExpression] = useState('');
  const [conversionType, setConversionType] = useState('infix-to-postfix');
  const [showVisualization, setShowVisualization] = useState(false);
  const [showRules, setShowRules] = useState(true);
  const [output, setOutput] = useState('');
  const [outputColor, setOutputColor] = useState('text-gray-700 dark:text-gray-300');
  const [steps, setSteps] = useState<VisualizationStep[]>([]);
  const [darkMode, setDarkMode] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);

  useEffect(() => {
    const savedMode = localStorage.getItem('darkMode');
    if (savedMode === 'enabled') {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleDarkMode = () => {
    const newMode = !darkMode;
    setDarkMode(newMode);

    if (newMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('darkMode', 'enabled');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('darkMode', 'disabled');
    }
  };

  const handleConvert = () => {
    if (!expression.trim()) {
      alert('⚠️ Please enter an expression!');
      return;
    }

    const validation = validateExpression(expression, conversionType);
    if (!validation.valid) {
      setOutput(`❌ Validation Error:\n\n${validation.error}`);
      setOutputColor('text-red-600 dark:text-red-400');
      setSteps([]);
      return;
    }

    try {
      const { result, steps: vizSteps } = convertExpression(
        expression,
        conversionType,
        showVisualization
      );

      setOutput(result);
      setOutputColor('text-green-600 dark:text-green-400');
      setSteps(vizSteps);
    } catch (error) {
      let errorMessage = '❌ Conversion Error:\n\n';

      if (error instanceof Error) {
        if (error.message.includes('parentheses')) {
          errorMessage += 'Parentheses mismatch detected!\n\n';
          errorMessage += 'Make sure all opening "(" have matching closing ")"';
        } else if (error.message.includes('stack')) {
          errorMessage += 'Invalid expression structure!\n\n';
          errorMessage += 'Check operator and operand placement.';
        } else {
          errorMessage += 'Invalid expression format!\n\n';
          errorMessage += 'Please verify:\n';
          errorMessage += '• Correct operator usage (+, -, *, /, ^)\n';
          errorMessage += '• Proper operand placement (letters/numbers)\n';
          errorMessage += '• Balanced parentheses for infix\n';
          errorMessage += '• Space-separated tokens for prefix/postfix';
        }
      }

      setOutput(errorMessage);
      setOutputColor('text-red-600 dark:text-red-400');
      setSteps([]);
    }
  };

  const handleClear = () => {
    setExpression('');
    setOutput('');
    setOutputColor('text-gray-700 dark:text-gray-300');
    setShowVisualization(false);
    setSteps([]);
  };

  const handleCopy = () => {
    if (!output || output.includes('Error')) {
      alert('⚠️ No result to copy!');
      return;
    }

    navigator.clipboard.writeText(output);
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 2000);
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleConvert();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 to-blue-800 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-5 transition-colors duration-300">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl p-10 max-w-3xl w-full transition-colors duration-300">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-gray-800 dark:text-gray-100 text-3xl font-bold">
            Expression Converter
          </h1>
          <button
            onClick={toggleDarkMode}
            className="bg-gray-200 dark:bg-gray-700 rounded-full w-12 h-12 flex items-center justify-center hover:scale-110 transition-transform"
            title="Toggle Dark Mode"
          >
            {darkMode ? (
              <Sun className="w-6 h-6 text-yellow-500" />
            ) : (
              <Moon className="w-6 h-6 text-gray-700" />
            )}
          </button>
        </div>

        <div className="mb-5">
          <label className="block mb-2 text-gray-600 dark:text-gray-400 font-semibold text-sm">
            Enter Expression:
          </label>
          <input
            type="text"
            value={expression}
            onChange={(e) => setExpression(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="e.g., A + B * C"
            autoComplete="off"
            className="w-full px-4 py-3 border-2 border-gray-300 dark:border-gray-600 rounded-lg text-base font-mono transition-all focus:outline-none focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-100"
          />
        </div>

        <div className="mb-5">
          <label className="block mb-2 text-gray-600 dark:text-gray-400 font-semibold text-sm">
            Select Conversion:
          </label>
          <select
            value={conversionType}
            onChange={(e) => {
              setConversionType(e.target.value);
              setOutput('');
              setOutputColor('text-gray-700 dark:text-gray-300');
              setSteps([]);
            }}
            className="w-full px-4 py-3 border-2 border-gray-300 dark:border-gray-600 rounded-lg text-base font-mono cursor-pointer transition-all focus:outline-none focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-100"
          >
            <option value="infix-to-postfix">Infix → Postfix</option>
            <option value="infix-to-prefix">Infix → Prefix</option>
            <option value="prefix-to-infix">Prefix → Infix</option>
            <option value="postfix-to-infix">Postfix → Infix</option>
            <option value="prefix-to-postfix">Prefix → Postfix</option>
            <option value="postfix-to-prefix">Postfix → Prefix</option>
          </select>
        </div>

        <div className="mb-5 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border-l-4 border-blue-500">
          <button
            onClick={() => setShowRules(!showRules)}
            className="flex items-center gap-2 text-blue-700 dark:text-blue-300 font-semibold hover:opacity-80 transition-opacity"
          >
            <ChevronDown
              className={`w-5 h-5 transition-transform ${showRules ? 'rotate-180' : ''}`}
            />
            <span>📋 Conversion Rules</span>
          </button>

          {showRules && (
            <div className="mt-3 space-y-2">
              <h3 className="font-bold text-gray-800 dark:text-gray-100">
                {conversionRulesMap[conversionType]?.title}
              </h3>
              <ol className="list-decimal list-inside space-y-1 text-sm text-gray-700 dark:text-gray-300">
                {conversionRulesMap[conversionType]?.rules.map((rule, idx) => (
                  <li key={idx}>{rule}</li>
                ))}
              </ol>
              <div className="mt-3 p-2 bg-white dark:bg-gray-700 rounded text-sm border border-gray-200 dark:border-gray-600">
                <span className="font-semibold text-gray-700 dark:text-gray-200">Example: </span>
                <span className="font-mono text-gray-600 dark:text-gray-400">
                  {conversionRulesMap[conversionType]?.example.input}
                </span>
                <span className="text-gray-500 mx-2">→</span>
                <span className="font-mono text-green-600 dark:text-green-400">
                  {conversionRulesMap[conversionType]?.example.output}
                </span>
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center gap-3 mb-5">
          <input
            type="checkbox"
            id="showVisualization"
            checked={showVisualization}
            onChange={(e) => setShowVisualization(e.target.checked)}
            className="w-5 h-5 cursor-pointer"
          />
          <label
            htmlFor="showVisualization"
            className="cursor-pointer text-gray-600 dark:text-gray-400 font-semibold"
          >
            Show step-by-step visualization
          </label>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-5">
          <button
            onClick={handleConvert}
            className="col-span-2 px-4 py-3.5 bg-gradient-to-r from-blue-500 to-blue-700 text-white rounded-lg text-lg font-semibold hover:-translate-y-0.5 hover:shadow-xl transition-all"
          >
            Convert
          </button>
          <button
            onClick={handleClear}
            className="col-span-2 md:col-span-1 px-4 py-3 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-100 rounded-lg text-base font-semibold hover:-translate-y-0.5 transition-all"
          >
            Clear All
          </button>
        </div>

        <div className="mb-0">
          <label className="block mb-2 text-gray-600 dark:text-gray-400 font-semibold text-sm">
            Result:
          </label>
          <textarea
            value={output}
            readOnly
            placeholder="Result will appear here..."
            className={`w-full px-4 py-3 border-2 border-gray-300 dark:border-gray-600 rounded-lg text-base font-mono min-h-20 resize-y bg-gray-50 dark:bg-gray-700 ${outputColor}`}
          />
          <div className="flex gap-3 mt-3">
            <button
              onClick={handleCopy}
              className="flex-1 px-4 py-2.5 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-100 rounded-md text-sm font-semibold hover:opacity-80 transition-all flex items-center justify-center gap-2"
            >
              {copySuccess ? (
                <>✅ Copied!</>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  Copy Result
                </>
              )}
            </button>
          </div>
        </div>

        <Visualization steps={steps} show={showVisualization && steps.length > 0} />
      </div>
    </div>
  );
}
