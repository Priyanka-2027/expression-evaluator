import { VisualizationStep } from '../utils/expressionConverter';

interface VisualizationProps {
  steps: VisualizationStep[];
  show: boolean;
}

export default function Visualization({ steps, show }: VisualizationProps) {
  if (!show || steps.length === 0) return null;

  return (
    <div className="mt-5 p-5 bg-gray-50 dark:bg-gray-800 rounded-lg border-2 border-gray-200 dark:border-gray-600">
      <h3 className="text-gray-800 dark:text-gray-100 mb-4 text-lg font-semibold flex items-center gap-2">
        <span>📊</span>
        <span>Step-by-Step Visualization</span>
      </h3>

      <div className="space-y-4">
        {steps.map((step, index) => (
          <div
            key={index}
            className="p-3 bg-white dark:bg-gray-700 rounded-md border-l-4 border-blue-500"
          >
            <div className="font-semibold text-gray-800 dark:text-gray-100 mb-2">
              Step {index + 1}: {step.description}
            </div>

            <div className="font-mono text-gray-600 dark:text-gray-300 text-sm">
              <div className="mb-1">
                <span>Stack: [</span>
                {step.stack.length > 0 ? (
                  step.stack.map((item, i) => (
                    <span
                      key={i}
                      className="inline-block px-2 py-1 bg-blue-500 text-white rounded mx-1 text-xs"
                    >
                      {item}
                    </span>
                  ))
                ) : (
                  <span> empty </span>
                )}
                <span>]</span>
              </div>

              <div>
                <span>Result: </span>
                {step.result ? (
                  <span className="inline-block px-2 py-1 bg-green-500 text-white rounded text-xs">
                    {step.result}
                  </span>
                ) : (
                  <span>[ ]</span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
