import ExpressionConverter from './components/ExpressionConverter';

function App() {
  return <ExpressionConverter />;
}

export default App;
