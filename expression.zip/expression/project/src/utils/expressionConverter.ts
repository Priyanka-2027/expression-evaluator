export interface VisualizationStep {
  description: string;
  stack: string[];
  result: string;
}

export function getPrecedence(op: string): number {
  if (op === '+' || op === '-') return 1;
  if (op === '*' || op === '/') return 2;
  if (op === '^') return 3;
  return 0;
}

export function getAssociativity(op: string): 'left' | 'right' {
  if (op === '^') return 'right';
  return 'left';
}

export function isOperator(c: string): boolean {
  return ['+', '-', '*', '/', '^'].includes(c);
}

export function isOperand(c: string): boolean {
  return /[a-zA-Z0-9]/.test(c);
}

function areParenthesesBalanced(expr: string): boolean {
  let count = 0;
  for (let char of expr) {
    if (char === '(') count++;
    if (char === ')') count--;
    if (count < 0) return false;
  }
  return count === 0;
}

export function validateExpression(expr: string, type: string): { valid: boolean; error: string | null } {
  const cleanExpr = expr.replace(/\s+/g, '');

  if (!cleanExpr) {
    return { valid: false, error: 'Expression cannot be empty!' };
  }

  const validChars = /^[a-zA-Z0-9+\-*/^().\s]+$/;
  if (!validChars.test(expr)) {
    return { valid: false, error: 'Invalid characters detected! Use only letters, numbers, +, -, *, /, ^, ( )' };
  }

  if (type.includes('infix')) {
    if (!areParenthesesBalanced(cleanExpr)) {
      return { valid: false, error: 'Unbalanced parentheses!' };
    }

    if (/[+\-*/^]{2,}/.test(cleanExpr.replace(/\(\-/g, ''))) {
      return { valid: false, error: 'Consecutive operators detected!' };
    }

    if (/^[+*/^]/.test(cleanExpr) || /[+\-*/^]$/.test(cleanExpr)) {
      return { valid: false, error: 'Expression cannot start or end with an operator!' };
    }
  } else if (type.includes('prefix') && !type.includes('to-prefix')) {
    if (!expr.includes(' ')) {
      return { valid: false, error: 'Prefix expressions must have spaces between tokens! (e.g., "+ A * B C")' };
    }
  } else if (type.includes('postfix') && !type.includes('to-postfix')) {
    if (!expr.includes(' ')) {
      return { valid: false, error: 'Postfix expressions must have spaces between tokens! (e.g., "A B C * +")' };
    }
  }

  return { valid: true, error: null };
}

export function infixToPostfix(expr: string, steps?: VisualizationStep[]): string {
  const stack: string[] = [];
  let result = '';

  for (let i = 0; i < expr.length; i++) {
    const c = expr[i];

    if (c === ' ') continue;

    if (isOperand(c)) {
      result += c + ' ';
      if (steps) steps.push({ description: `Read operand '${c}'`, stack: [...stack], result: result.trim() });
    }
    else if (c === '(') {
      stack.push(c);
      if (steps) steps.push({ description: `Push '(' to stack`, stack: [...stack], result: result.trim() });
    }
    else if (c === ')') {
      while (stack.length > 0 && stack[stack.length - 1] !== '(') {
        result += stack.pop() + ' ';
      }
      if (stack.length === 0) {
        throw new Error('Mismatched parentheses');
      }
      stack.pop();
      if (steps) steps.push({ description: `Pop operators until '('`, stack: [...stack], result: result.trim() });
    }
    else if (isOperator(c)) {
      while (stack.length > 0 && stack[stack.length - 1] !== '(') {
        const topOp = stack[stack.length - 1];
        const topPrec = getPrecedence(topOp);
        const currPrec = getPrecedence(c);

        if (topPrec > currPrec ||
            (topPrec === currPrec && getAssociativity(c) === 'left')) {
          result += stack.pop() + ' ';
        } else {
          break;
        }
      }
      stack.push(c);
      if (steps) steps.push({ description: `Process operator '${c}'`, stack: [...stack], result: result.trim() });
    }
  }

  while (stack.length > 0) {
    const op = stack.pop();
    if (op === '(' || op === ')') {
      throw new Error('Mismatched parentheses');
    }
    result += op + ' ';
  }

  if (steps) steps.push({ description: 'Pop remaining operators', stack: [...stack], result: result.trim() });

  return result.trim();
}

export function infixToPrefix(expr: string, steps?: VisualizationStep[]): string {
  expr = expr.split('').reverse().join('');
  expr = expr.replace(/\(/g, 'temp')
             .replace(/\)/g, '(')
             .replace(/temp/g, ')');

  let postfix = infixToPostfix(expr, steps);
  return postfix.split('').reverse().join('');
}

export function prefixToInfix(expr: string, steps?: VisualizationStep[]): string {
  const stack: string[] = [];
  const tokens = expr.split(' ').filter(t => t);

  for (let i = tokens.length - 1; i >= 0; i--) {
    const token = tokens[i];

    if (isOperator(token)) {
      const op1 = stack.pop();
      const op2 = stack.pop();
      const newExpr = `(${op1} ${token} ${op2})`;
      stack.push(newExpr);
      if (steps) steps.push({ description: `Process operator '${token}'`, stack: [...stack], result: '' });
    } else {
      stack.push(token);
      if (steps) steps.push({ description: `Push operand '${token}'`, stack: [...stack], result: '' });
    }
  }

  return stack.pop() || '';
}

export function postfixToInfix(expr: string, steps?: VisualizationStep[]): string {
  const stack: string[] = [];
  const tokens = expr.split(' ').filter(t => t);

  for (let token of tokens) {
    if (isOperator(token)) {
      const op2 = stack.pop();
      const op1 = stack.pop();
      const newExpr = `(${op1} ${token} ${op2})`;
      stack.push(newExpr);
      if (steps) steps.push({ description: `Process operator '${token}'`, stack: [...stack], result: '' });
    } else {
      stack.push(token);
      if (steps) steps.push({ description: `Push operand '${token}'`, stack: [...stack], result: '' });
    }
  }

  return stack.pop() || '';
}

export function prefixToPostfix(expr: string, steps?: VisualizationStep[]): string {
  const infix = prefixToInfix(expr, steps);
  return infixToPostfix(infix);
}

export function postfixToPrefix(expr: string, steps?: VisualizationStep[]): string {
  const infix = postfixToInfix(expr, steps);
  return infixToPrefix(infix);
}

export function convertExpression(
  expr: string,
  type: string,
  visualize: boolean
): { result: string; steps: VisualizationStep[] } {
  const steps: VisualizationStep[] = visualize ? [] : [];
  let result: string;

  switch(type) {
    case 'infix-to-postfix':
      result = infixToPostfix(expr, visualize ? steps : undefined);
      break;
    case 'infix-to-prefix':
      result = infixToPrefix(expr, visualize ? steps : undefined);
      break;
    case 'prefix-to-infix':
      result = prefixToInfix(expr, visualize ? steps : undefined);
      break;
    case 'postfix-to-infix':
      result = postfixToInfix(expr, visualize ? steps : undefined);
      break;
    case 'prefix-to-postfix':
      result = prefixToPostfix(expr, visualize ? steps : undefined);
      break;
    case 'postfix-to-prefix':
      result = postfixToPrefix(expr, visualize ? steps : undefined);
      break;
    default:
      throw new Error('Invalid conversion type');
  }

  return { result, steps };
}
